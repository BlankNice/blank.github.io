<a name="3.0.2"></a>
## [3.0.2](https://github.com/equinusocio/material-theme/compare/v3.0.1...v3.0.2) (2016-07-07)


### Bug Fixes

* Fix activeGuide and StackGuide darker variant ([9c2ac2e](https://github.com/equinusocio/material-theme/commit/9c2ac2e)), closes [#892](https://github.com/equinusocio/material-theme/issues/892)
* Update icons file preferences and associations ([bffa1f8](https://github.com/equinusocio/material-theme/commit/bffa1f8)), closes [#890](https://github.com/equinusocio/material-theme/issues/890)


### Features

* add Material Theme gutter theme for SublimeLinter ([156f734](https://github.com/equinusocio/material-theme/commit/156f734))


<a name="3.0.1"></a>
## [3.0.1](https://github.com/equinusocio/material-theme/compare/v3.0.0...v3.0.1) (2016-06-28)


### Bug Fixes

* .stata to .do ([9eb7d27](https://github.com/equinusocio/material-theme/commit/9eb7d27))
* Fix gutter colors and themes ([bb4fd2a](https://github.com/equinusocio/material-theme/commit/bb4fd2a)), closes [#887](https://github.com/equinusocio/material-theme/issues/887)
* Optimize image assets ([fe31c02](https://github.com/equinusocio/material-theme/commit/fe31c02))
* Selected item tree indicator ([58a82fc](https://github.com/equinusocio/material-theme/commit/58a82fc))
* SublimeLinter gutter colors ([f696f89](https://github.com/equinusocio/material-theme/commit/f696f89)), closes [#880](https://github.com/equinusocio/material-theme/issues/880)


### Features

* Add support to the references popup ([7208105](https://github.com/equinusocio/material-theme/commit/7208105)), closes [#882](https://github.com/equinusocio/material-theme/issues/882)



<a name="3.0.1"></a>
## [3.0.1](https://github.com/equinusocio/material-theme/compare/v3.0.0...v3.0.1) (2016-06-28)


### Bug Fixes

* .stata to .do ([9eb7d27](https://github.com/equinusocio/material-theme/commit/9eb7d27))
* Fix gutter colors and themes ([bb4fd2a](https://github.com/equinusocio/material-theme/commit/bb4fd2a)), closes [#887](https://github.com/equinusocio/material-theme/issues/887)
* Optimize image assets ([fe31c02](https://github.com/equinusocio/material-theme/commit/fe31c02))
* Selected item tree indicator ([58a82fc](https://github.com/equinusocio/material-theme/commit/58a82fc))
* SublimeLinter gutter colors ([f696f89](https://github.com/equinusocio/material-theme/commit/f696f89)), closes [#880](https://github.com/equinusocio/material-theme/issues/880)


### Features

* Add support to the references popup ([7208105](https://github.com/equinusocio/material-theme/commit/7208105)), closes [#882](https://github.com/equinusocio/material-theme/issues/882)



<a name="3.0.1"></a>
## [3.0.1](https://github.com/equinusocio/material-theme/compare/v3.0.0...v3.0.1) (2016-06-28)


### Bug Fixes

* .stata to .do ([9eb7d27](https://github.com/equinusocio/material-theme/commit/9eb7d27))
* Fix gutter colors and themes ([bb4fd2a](https://github.com/equinusocio/material-theme/commit/bb4fd2a)), closes [#887](https://github.com/equinusocio/material-theme/issues/887)
* Optimize image assets ([fe31c02](https://github.com/equinusocio/material-theme/commit/fe31c02))
* Selected item tree indicator ([58a82fc](https://github.com/equinusocio/material-theme/commit/58a82fc))
* SublimeLinter gutter colors ([f696f89](https://github.com/equinusocio/material-theme/commit/f696f89)), closes [#880](https://github.com/equinusocio/material-theme/issues/880)


### Features

* Add support to the references popup ([7208105](https://github.com/equinusocio/material-theme/commit/7208105)), closes [#882](https://github.com/equinusocio/material-theme/issues/882)



<a name="3.0.0"></a>
# [3.0.0](https://github.com/equinusocio/material-theme/compare/v2.1.6...v3.0.0) (2016-06-11)


### Bug Fixes

* add highlighting of the invalid scope ([a1c7ed5](https://github.com/equinusocio/material-theme/commit/a1c7ed5))
* Add widgets watcher ([c95dab2](https://github.com/equinusocio/material-theme/commit/c95dab2))
* default line highlight color ([c75ac15](https://github.com/equinusocio/material-theme/commit/c75ac15))
* default scheme comments color ([dcf0ebd](https://github.com/equinusocio/material-theme/commit/dcf0ebd))
* remove hexbgr reverse conversion ([842f8c5](https://github.com/equinusocio/material-theme/commit/842f8c5))
* Scheme compiler and add new scheme vars ([fb7545d](https://github.com/equinusocio/material-theme/commit/fb7545d))
* Schemes color ([d2c5cf1](https://github.com/equinusocio/material-theme/commit/d2c5cf1))
* sublimelinter error foreground color ([71ce945](https://github.com/equinusocio/material-theme/commit/71ce945))


### Features

* Add [@3x](https://github.com/3x) retina assets ([6bd54e8](https://github.com/equinusocio/material-theme/commit/6bd54e8))



